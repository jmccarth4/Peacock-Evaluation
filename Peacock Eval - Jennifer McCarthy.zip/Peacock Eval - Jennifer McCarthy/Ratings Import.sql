-- Code to import JSON

-- Check to ensure valid format and find column names
DECLARE @JSON VARCHAR(max)
SELECT @JSON = BulkColumn
FROM openrowset (bulk 'C:\Users\Jennifer.McCarthy\Downloads\peacock-de-eval.tar\peacock-de-eval\ratings.tar\ratings\data\messages\messages.json', SINGLE_CLOB) as import
if (isjson(@json)=1)
print 'It is a valid JSON'
ELSE 
print 'Error in JSON format'

-- Create Table to Store
DROP TABLE IF EXISTS c_TACO.dbo.test
CREATE TABLE c_TACO.dbo.test
(
	[UserID] INT,
	[TitleRated] VARCHAR(10),
	[UserRating] INT,
	[DateOfRating] DATE
)

-- Import to Table
DECLARE @JSON2 varchar(max)
SELECT @JSON2 = BulkColumn
FROM openrowset (bulk 'C:\Users\Jennifer.McCarthy\Downloads\peacock-de-eval.tar\peacock-de-eval\ratings.tar\ratings\data\messages\messages.json', SINGLE_CLOB) as import
INSERT INTO c_TACO.dbo.test ([UserID], [TitleRated], [UserRating], [DateOfRating])
SELECT [id], [item], [rating], [datetime]
FROM OPENJSON(@JSON2)
WITH 
(
	[id] INT,
	[item] VARCHAR(10),
	[rating] INT,
	[datetime] DATE

)

-- 4136360 initial count
SELECT count(*)
FROM c_TACO.dbo.test


select distinct [UserRating] 
from c_TACO.dbo.test

-- invalid ratings - count of 8 to delete
select count(*)
-- select *
-- delete
from c_TACO.dbo.test
where [UserRating] = '-999'

-- 73421 distinct users with a rating
select count(distinct [UserID])
from c_TACO.dbo.test

-- 100 distinct titles
select count(distinct [TitleRated])
from c_TACO.dbo.test

-- look for duplicates
-- confirmed each user only has a single rating for 1 title
select [UserID], [TitleRated]
from c_TACO.dbo.test
group by [UserID], [TitleRated]
having count(*) > 1


select top 100 *
from c_TACO.dbo.test

-- Drop table when finished
DROP TABLE IF EXISTS c_TACO.dbo.test


